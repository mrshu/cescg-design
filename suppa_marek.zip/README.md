# cescg-design

The new design (as of 2016) for the website of Central European Seminar on
Computer Graphics for students (http://www.cescg.org/)

A live preview can be found at http://mrshu.github.io/cescg-design/
